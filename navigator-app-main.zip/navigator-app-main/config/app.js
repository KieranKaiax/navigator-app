import { configure } from './defaults';

/** 
 * ----------------------------------------------------------
 * Storefront App Configuration
 * ----------------------------------------------------------
 *
 * @type {object} 
 */
const AppConfig = configure('AppConfig', {});

export default AppConfig;